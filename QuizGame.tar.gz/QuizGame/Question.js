var Question = function(text, answer, id) {
	this.text	= text;
	this.answer = answer;
	this.id		= id;
};


module.exports = Question;